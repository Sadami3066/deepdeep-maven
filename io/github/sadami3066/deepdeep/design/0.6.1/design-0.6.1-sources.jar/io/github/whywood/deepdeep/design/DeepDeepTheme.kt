package io.github.whywood.deepdeep.design

import android.content.Context
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ThemePreset { SYSTEM, DEEP_DEEP, SANTORINI, OCEANIC }

@Immutable
data class DeepDeepColors(
    val dark: Boolean,
    val paper: Color,
    val surface: Color,
    val raised: Color,
    val ink: Color,
    val inkSecondary: Color,
    val inkTertiary: Color,
    val accent: Color,
    val accentPressed: Color,
    val onAccent: Color,
    val accentSoft: Color,
    val danger: Color,
    val success: Color,
    val warning: Color,
    val hairline: Color,
    val wash: Color,
    val composer: Color,
    val scrim: Color,
    val codeBackground: Color,
    val inlineCodeBackground: Color,
    val codeKeyword: Color,
    val codeString: Color,
    val codeComment: Color,
    val codeNumber: Color,
    val codeFunction: Color,
    val codeType: Color,
) {
    val userBubble: Color get() = accentSoft
    val onUserBubble: Color get() = ink
}

private val Light = DeepDeepColors(
    dark = false,
    paper = Color(0xFFF7F8F8),
    surface = Color(0xFFFFFFFF),
    raised = Color(0xFFFFFFFF),
    ink = Color(0xFF0B1220),
    inkSecondary = Color(0xFF354451),
    inkTertiary = Color(0xFF64727E),
    accent = Color(0xFF2563EB),
    accentPressed = Color(0xFF1D4ED8),
    onAccent = Color(0xFFFFFFFF),
    accentSoft = Color(0xFFE8F0FE),
    danger = Color(0xFFD93025),
    success = Color(0xFF188038),
    warning = Color(0xFFB45309),
    hairline = Color(0xFFDDE5E7),
    wash = Color(0xFFEDF3F4),
    composer = Color(0xFFFFFFFF),
    scrim = Color(0x520B1220),
    codeBackground = Color(0x0F0B1220),
    inlineCodeBackground = Color(0xFFF2F3F4),
    codeKeyword = Color(0xFF7C3AED),
    codeString = Color(0xFF15803D),
    codeComment = Color(0xFF64727E),
    codeNumber = Color(0xFFB45309),
    codeFunction = Color(0xFF1D4ED8),
    codeType = Color(0xFF0E7490),
)

val LocalDeepDeepColors = staticCompositionLocalOf { Light }

enum class DdFontStyle(val id: String, val displayName: String) {
    FREDOKA("fredoka", "Fredoka"),
    OPEN_RUNDE("open-runde", "Open Runde"),
    LORA("lora", "Lora"),
    MANROPE("manrope", "Manrope"),
    SYSTEM("system", "System"),
    ;

    companion object {
        fun fromId(id: String?): DdFontStyle = entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

object DdFonts {
    private val openRundeFonts = listOf(
        DdCompositeFont(R.font.open_runde_regular, FontWeight.Normal, variable = false),
        DdCompositeFont(R.font.open_runde_medium, FontWeight.Medium, variable = false),
        DdCompositeFont(R.font.open_runde_semibold, FontWeight.SemiBold, variable = false),
    )
    private val fredokaFonts = variableFonts(R.font.fredoka_variable)
    private val loraFonts = variableFonts(R.font.lora_variable)
    private val manropeFonts = variableFonts(R.font.manrope_variable)
    private val systemFonts = listOf(
        DdCompositeFont(SYSTEM_LATIN_RES, FontWeight.Normal, variable = false),
        DdCompositeFont(SYSTEM_LATIN_RES, FontWeight.Medium, variable = false),
        DdCompositeFont(SYSTEM_LATIN_RES, FontWeight.SemiBold, variable = false),
    )

    private val families = mapOf(
        DdFontStyle.FREDOKA to FontFamily(fredokaFonts),
        DdFontStyle.OPEN_RUNDE to FontFamily(openRundeFonts),
        DdFontStyle.LORA to FontFamily(loraFonts),
        DdFontStyle.MANROPE to FontFamily(manropeFonts),
        DdFontStyle.SYSTEM to FontFamily(systemFonts),
    )
    var style: DdFontStyle = DdFontStyle.SYSTEM
        private set

    fun apply(style: DdFontStyle) {
        this.style = style
    }

    fun familyFor(style: DdFontStyle): FontFamily = families.getValue(style)

    fun preload(context: Context) {
        val fonts = when (style) {
            DdFontStyle.FREDOKA -> fredokaFonts
            DdFontStyle.OPEN_RUNDE -> openRundeFonts
            DdFontStyle.LORA -> loraFonts
            DdFontStyle.MANROPE -> manropeFonts
            DdFontStyle.SYSTEM -> systemFonts
        }
        DdCompositeTypefaceLoader.preload(context, fonts)
    }

    val Sans: FontFamily get() = familyFor(style)

    val Display: FontFamily get() = familyFor(style)

    private fun variableFonts(resId: Int): List<DdCompositeFont> = listOf(
        DdCompositeFont(resId, FontWeight.Normal, variable = true),
        DdCompositeFont(resId, FontWeight.Medium, variable = true),
        DdCompositeFont(resId, FontWeight.SemiBold, variable = true),
    )
}

object DdType {
    val wordmark: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Display,
            fontWeight = FontWeight.SemiBold,
            fontSize = 27.sp,
            lineHeight = 32.sp,
            letterSpacing = (-0.4).sp,
        )
    val display: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Display,
            fontWeight = FontWeight.SemiBold,
            fontSize = 40.sp,
            lineHeight = 49.sp,
            letterSpacing = (-0.3).sp,
        )
    val pageTitle: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Display,
            fontWeight = FontWeight.SemiBold,
            fontSize = 32.sp,
            lineHeight = 40.sp,
            letterSpacing = (-0.2).sp,
        )
    val heading: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Display,
            fontWeight = FontWeight.SemiBold,
            fontSize = 24.sp,
            lineHeight = 31.sp,
        )
    val body: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.Normal,
            fontSize = 16.sp,
            lineHeight = 26.sp,
        )
    val bodySmall: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.Normal,
            fontSize = 14.sp,
            lineHeight = 21.sp,
        )
    val label: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.Medium,
            fontSize = 14.sp,
            lineHeight = 20.sp,
        )
    val chip: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
            lineHeight = 18.sp,
        )
    val button: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp,
            lineHeight = 20.sp,
        )
    val micro: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            letterSpacing = 1.7.sp,
        )
    val numeric: TextStyle
        get() = TextStyle(
            fontFamily = DdFonts.Sans,
            fontWeight = FontWeight.Medium,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            letterSpacing = 0.2.sp,
        )
}

private fun deepDeepTypography(): Typography = Typography(
    displayLarge = DdType.display.copy(fontSize = 52.sp, lineHeight = 60.sp),
    displayMedium = DdType.display,
    displaySmall = DdType.pageTitle,
    headlineLarge = DdType.pageTitle,
    headlineMedium = DdType.heading,
    headlineSmall = DdType.heading.copy(fontSize = 21.sp, lineHeight = 28.sp),
    titleLarge = DdType.label.copy(fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium = DdType.label,
    titleSmall = DdType.label.copy(fontSize = 13.sp, lineHeight = 18.sp),
    bodyLarge = DdType.body,
    bodyMedium = DdType.bodySmall,
    bodySmall = DdType.bodySmall.copy(fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = DdType.button,
    labelMedium = DdType.label,
    labelSmall = DdType.micro,
)

private val DeepDeepShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

private fun DeepDeepColors.materialScheme() = if (dark) {
    darkColorScheme(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = accentSoft,
        onPrimaryContainer = ink,
        secondary = inkSecondary,
        onSecondary = paper,
        background = paper,
        onBackground = ink,
        surface = surface,
        onSurface = ink,
        surfaceVariant = wash,
        onSurfaceVariant = inkSecondary,
        surfaceContainer = surface,
        surfaceContainerHigh = raised,
        surfaceContainerHighest = raised,
        surfaceContainerLow = paper,
        surfaceContainerLowest = paper,
        outline = hairline,
        outlineVariant = hairline,
        inverseSurface = ink,
        inverseOnSurface = paper,
        error = inkSecondary,
        onError = paper,
        scrim = Color.Black,
    )
} else {
    lightColorScheme(
        primary = accent,
        onPrimary = onAccent,
        primaryContainer = accentSoft,
        onPrimaryContainer = ink,
        secondary = inkSecondary,
        onSecondary = paper,
        background = paper,
        onBackground = ink,
        surface = surface,
        onSurface = ink,
        surfaceVariant = wash,
        onSurfaceVariant = inkSecondary,
        surfaceContainer = surface,
        surfaceContainerHigh = raised,
        surfaceContainerHighest = raised,
        surfaceContainerLow = paper,
        surfaceContainerLowest = paper,
        outline = hairline,
        outlineVariant = hairline,
        inverseSurface = ink,
        inverseOnSurface = paper,
        error = inkSecondary,
        onError = paper,
        scrim = Color.Black,
    )
}
@Composable
fun DeepDeepTheme(
    preset: ThemePreset = ThemePreset.SYSTEM,
    fontStyle: DdFontStyle = DdFonts.style,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val colors = when (preset) {
        ThemePreset.SYSTEM -> if (systemDark) DdTheme.darkOceanic() else DdTheme.lightSantorini()
        ThemePreset.SANTORINI -> DdTheme.lightSantorini()
        ThemePreset.OCEANIC -> DdTheme.darkOceanic()
        ThemePreset.DEEP_DEEP -> Light
    }
    DdFonts.apply(fontStyle)
    val typography = remember(fontStyle) { deepDeepTypography() }
    val colorScheme = remember(colors) { colors.materialScheme() }
    CompositionLocalProvider(LocalDeepDeepColors provides colors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            shapes = DeepDeepShapes,
            content = content,
        )
    }
}

@Composable
fun deepDeepColors(): DeepDeepColors = LocalDeepDeepColors.current
